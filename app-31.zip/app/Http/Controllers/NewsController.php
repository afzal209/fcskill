<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News;
class NewsController extends Controller
{
    //
    public function index(){
        $news = News::orderBy('created_at','desc')->get();
        return view('news',compact('news'));
    }
    public function add(){
        return view("addNews");
    }

    public function store(Request $request){
            $this->validate($request, [
                'news_text' => 'required'
            ]);
            
            $news = new News;
            $news->news_text = $request->news_text;
            $news->save();

            return redirect()->back()->with('doneMessage', 'Successfully saved.');
    }
    public function edit($id){

        $new = News::find($id);

        if ($new) {
            return view("editNews", compact("new"));
        } else {
            return redirect('news');
        }
    }


}